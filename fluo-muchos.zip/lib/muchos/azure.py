#!/usr/bin/env python3
#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import os
from sys import exit
from .util import AMI_HELP_MSG, get_block_device_map
from os.path import isfile
import time
from .existing import ExistingCluster
import subprocess
from os.path import isfile, join
from azure.common.client_factory import get_client_from_cli_profile
from azure.mgmt.compute import ComputeManagementClient

# For Muchos deployments on Microsoft Azure, we use Virtual Machine Scale Sets (VMSS)
# VMSS is the most efficient way to provision large numbers of VMs in Azure
# Hence the class is called VmssCluster.
class VmssCluster(ExistingCluster):

    def __init__(self, config):
        ExistingCluster.__init__(self, config)

    def launch(self):
        config = self.config
        with open(join(config.deploy_path, "ansible/roles/azure/vars/main.yml"), 'w') as vmss_vars_file:
          for (name, value) in config.items("azure"):
            print("{0}: {1}".format(name, value), file=vmss_vars_file)
          print("admin_username: " + config.get("general","cluster_user"), file=vmss_vars_file)
          print("vmss_name: " + config.cluster_name, file=vmss_vars_file)
          print("deploy_path: " + config.deploy_path, file=vmss_vars_file)
        print("Launching {0} cluster".format(self.config.cluster_name))
        subprocess.call(["ansible-playbook",join(config.deploy_path, "ansible/azure.yml")])

    def status(self):
        config = self.config
        azure_vars_dict = dict(config.items("azure"))
        compute_client = get_client_from_cli_profile(ComputeManagementClient)
        vmss_status = compute_client.virtual_machine_scale_sets.get(azure_vars_dict["resource_group"], self.config.cluster_name)
        print('name:', vmss_status.name, '\nprovisioning_state:', vmss_status.provisioning_state)
        
