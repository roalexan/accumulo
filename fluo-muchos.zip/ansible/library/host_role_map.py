#!/usr/bin/python3

from ansible.module_utils.basic import *
from collections import defaultdict

def label(hosts, labels):
    hld = defaultdict(list)
    for i, host in enumerate(hosts):
        for l, n in labels.items():
            if i < n:
                hld[host].append(l)
    return hld


def stringify(L):
    # Flatten the list of dicts
    labels = {k: v for d in L for k, v in d.items()}
    label_string_dict = {k: ','.join(v) for k, v in labels.items()}
    label_list = ['%s = %s' % (k, v) for k, v in label_string_dict.items()]
    return '\n'.join(label_list)


def main():

    fields = {
        "hosts": {"required": True, "type": "list"},
        "vars_list": {"required": True, "type": "dict" },
        "cluster_name": {"required": True, "type": "str" }
    }


    module = AnsibleModule(argument_spec=fields)
    vars_list = module.params['vars_list']
    hosts = module.params['hosts']
    cluster_name = module.params['cluster_name']
    mp = {x['name_prefix']: x['roles'] for x in vars_list['vars_list']}

    hd = defaultdict(list)
    for host in hosts:
        hd[host['key']].append(host['value'])

    label_tuples = {k+cluster_name: (hd[k+cluster_name], v) for k, v in mp.items()}
    label_lists = [label(*v) for k, v in label_tuples.items()]
    result_string = str(stringify(label_lists))
#    module.exit_json(changed=False, meta=module.params)

    # the next few lines create two lists - one for each disk layout type - and write them to files on disk
    diskTypeMap = {x['name_prefix']: x['disk_layout'] for x in vars_list['vars_list']}
    list_jbod_instances = []
    list_lvm_instances = []

    for k, v in diskTypeMap.items():
        for hostTmp in hd[k+cluster_name]:
            if v == 'jbod': list_jbod_instances.append(hostTmp)
            if v == 'lvm': list_lvm_instances.append(hostTmp)

    jbod_file = open("/tmp/jbod_hosts.txt", "w")
    jbod_file.write("[jbod_hosts]\n")
    jbod_file.write("\n".join(list_jbod_instances))
    jbod_file.write("\n")
    jbod_file.close()

    lvm_file = open("/tmp/lvm_hosts.txt", "w")
    lvm_file.write("[lvm_hosts]\n")
    lvm_file.write("\n".join(list_lvm_instances))
    lvm_file.write("\n")
    lvm_file.close()

    module.exit_json(result=result_string)

if __name__ == '__main__':
    main()
